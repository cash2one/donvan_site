===================
``mptt.exceptions``
===================

.. automodule:: mptt.exceptions
    :members:
    :undoc-members:
